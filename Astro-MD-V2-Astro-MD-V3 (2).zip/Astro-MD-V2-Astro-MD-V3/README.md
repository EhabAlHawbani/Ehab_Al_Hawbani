# ASTRO-MD

   
  ### ඔබට පහසුවෙන් QR කේතය Repl.it මඟින් ලබා ගත හැක.. පහල බටනය CLICK කරන්න

[![Run on Repl.it](https://repl.it/badge/github/quiec/whatsasena)](https://replit.com/@SamPandey001/Vihanga?output%20only=1&lite=1#index.js)

## QR කේතය ලබා ගත් පසු Bot deploy කිරීමට පහල බටනය CLICK කරන්න..
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/vihangayt0/Astro-MD-V2)

---------------------------------   

 ###  Developer : Vihanga-YT

## Thanks To
##### ◉[@adiwajshing](https://github.com/adiwajshing/) for coded.
##### ◉[@yusufusta](https://github.com/yusufusta/) for coded.
##### ◉[@SamPandey001](https://github.com/SamPandey001) For session and multi file auth State.
##### ◉[@sanuwaofficial](https://github.com/sanuwaofficial) for apk downloader and help. 
##### ◉[@edm-official](https://github.com/edm-official) for base and help.
##### ◉[@DarkMakerofc](https://github.com/DarkMakerofc) for help. 
